<?php
    require_once "../Modelo/DAOProducto.php";

function mostrarCarrito(){
    foreach ($_SESSION["carrito"] as $producto) {
        print "<tr>";
        print "<td>" . $producto->getId() . "</td>";
        print "<td>" . $producto->getNombre() . "</td>";
        print "<td>" . $producto->getDescripcion() . "</td>";
        print "<td>" . $producto->getPrecio() . "</td>";
        print "<td>" . $producto->getClienteId() . "</td>";
        print "<td>" . $producto->getRuta() . "</td>";
        print "<td><button><a href='carrito.php?idb=".$producto->getId()."'>Borrar producto</a></button></td>";
        print "</tr>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito</title>
</head>
    <nav>
        <div>
            <?php
                $class = "hidden";
                $nombre = "";
                $apellido = "";
                if(isset($_SESSION['cliente'])){
                    $class = "";
                    $nombre = $_SESSION['cliente']->getNombre();
                    $apellido = $_SESSION['cliente']->getApellido();
                }
                print '<p class="'.$class.'">Administrador '.$nombre.' '.$apellido.' <a class="btn" href="../Controlador/controlPeticionesCliente.php?cliente=true">Cerrar sesión</a></p>'
            ?>
        </div>
        <div>
            <a href="index.php">Página Principal</a>
            <a href="inicioSesion.php">Iniciar Sesión</a>
            <a href="registro.php">Registrarse</a>
            <a href="trastienda.php">Trastienda</a>
            <img src="">
        </div>
    </na>
<body>
    <h1>Carrito</h1>
    <table style="border: 1px solid black">
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Cliente Id</th>
            <th>Ruta imagen</th>
        </tr>
        <?php
            if (!isset($_SESSION["carrito"])){
                $_SESSION["carrito"] = [];
            }

            if (isset($_GET["idb"])){
                foreach ($_SESSION["carrito"] as $id => $item){
                    if ($item->getId() == $_GET["idb"]){
                        unset($_SESSION["carrito"][$id]);
                        header("location:carrito.php");
                        exit();
                    }
                }
            }

            if (isset($_GET["id"])) {
                $DAOProducto  = new DAOProducto();
                $_SESSION["carrito"][] = $DAOProducto->getProductByID($_GET["id"]);

                header("location:index.php");
                exit();
            }
            else{
                if (count($_SESSION["carrito"]) > 0){
                        mostrarCarrito();
                }
                else{
                    print "<p>El carrito está vacío.</p>";
                }
            }
        ?>
    </table>
</body>
</html>

